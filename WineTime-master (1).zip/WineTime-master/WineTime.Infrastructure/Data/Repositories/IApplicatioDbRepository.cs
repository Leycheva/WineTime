﻿namespace WineTime.Infrastructure.Data.Repositories
{
    using WineTime.Infrastructure.Data.Common;

    public interface IApplicatioDbRepository : IRepository
    {
    }
}
