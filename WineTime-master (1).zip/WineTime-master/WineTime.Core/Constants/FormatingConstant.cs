﻿namespace WineTime.Core.Constants
{
    public class FormatingConstant
    {
        public const string NormalDateFormat = "dd.MM.yyyy";
    }
}
